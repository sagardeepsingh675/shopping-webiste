import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { BarChart3, Users, Package, DollarSign, TrendingUp, ShoppingBag } from 'lucide-react';
import toast from 'react-hot-toast';

interface DashboardStats {
  totalUsers: number;
  newUsersToday: number;
  totalRevenue: number;
  averageOrderValue: number;
  totalOrders: number;
}

interface RecentOrder {
  _id: string;
  user: {
    name: string;
  };
  total: number;
  status: string;
  createdAt: string;
}

function AdminDashboard() {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [recentOrders, setRecentOrders] = useState<RecentOrder[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      const [statsRes, ordersRes] = await Promise.all([
        axios.get('http://localhost:3000/api/users/stats'),
        axios.get('http://localhost:3000/api/orders?limit=5')
      ]);

      setStats(statsRes.data);
      setRecentOrders(ordersRes.data);
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
      toast.error('Failed to load dashboard data');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gray-900" />
      </div>
    );
  }

  const cards = [
    {
      title: 'Total Revenue',
      value: stats ? `$${stats.totalRevenue.toLocaleString()}` : '$0',
      icon: <DollarSign className="w-6 h-6 text-green-600" />,
      bgColor: 'bg-green-50'
    },
    {
      title: 'Total Orders',
      value: stats?.totalOrders || 0,
      icon: <ShoppingBag className="w-6 h-6 text-blue-600" />,
      bgColor: 'bg-blue-50'
    },
    {
      title: 'Total Customers',
      value: stats?.totalUsers || 0,
      icon: <Users className="w-6 h-6 text-purple-600" />,
      bgColor: 'bg-purple-50'
    },
    {
      title: 'Avg. Order Value',
      value: stats ? `$${stats.averageOrderValue.toFixed(2)}` : '$0',
      icon: <TrendingUp className="w-6 h-6 text-orange-600" />,
      bgColor: 'bg-orange-50'
    }
  ];

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Dashboard</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {cards.map((card, index) => (
          <div
            key={index}
            className={`${card.bgColor} rounded-lg p-6 flex items-center justify-between`}
          >
            <div>
              <p className="text-gray-600 mb-1">{card.title}</p>
              <p className="text-2xl font-bold">{card.value}</p>
            </div>
            <div className="p-3 rounded-full bg-white shadow-sm">{card.icon}</div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow-sm p-6">
          <h2 className="text-xl font-semibold mb-4">Recent Orders</h2>
          <div className="space-y-4">
            {recentOrders.map((order) => (
              <div
                key={order._id}
                className="flex items-center justify-between py-3 border-b last:border-0"
              >
                <div>
                  <p className="font-medium">Order #{order._id.slice(-6)}</p>
                  <p className="text-sm text-gray-600">{order.user.name}</p>
                </div>
                <div className="text-right">
                  <p className="font-medium">${order.total.toFixed(2)}</p>
                  <p className="text-sm text-gray-600">
                    {new Date(order.createdAt).toLocaleDateString()}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm p-6">
          <h2 className="text-xl font-semibold mb-4">Quick Stats</h2>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-gray-600">New Users Today</span>
              <span className="font-semibold">{stats?.newUsersToday}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Active Orders</span>
              <span className="font-semibold">
                {recentOrders.filter(o => o.status !== 'delivered').length}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Conversion Rate</span>
              <span className="font-semibold">
                {stats ? ((stats.totalOrders / stats.totalUsers) * 100).toFixed(1) : 0}%
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default AdminDashboard;