import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import useStore from '../store/useStore';

interface AuthGuardProps {
  children: React.ReactNode;
  requireAdmin?: boolean;
}

function AuthGuard({ children, requireAdmin = false }: AuthGuardProps) {
  const navigate = useNavigate();
  const user = useStore((state) => state.user);

  useEffect(() => {
    if (!user) {
      navigate('/login');
    } else if (requireAdmin && user.role !== 'admin') {
      navigate('/');
    }
  }, [user, requireAdmin, navigate]);

  if (!user || (requireAdmin && user.role !== 'admin')) {
    return null;
  }

  return <>{children}</>;
}

export default AuthGuard;