import express from 'express';
import User from '../models/User.js';
import Order from '../models/Order.js';
import { adminAuth } from '../middleware/auth.js';

const router = express.Router();

// Get all users (admin only)
router.get('/', adminAuth, async (req, res) => {
  try {
    const users = await User.find({ role: 'user' }).select('-password');
    
    // Get order statistics for each user
    const usersWithStats = await Promise.all(
      users.map(async (user) => {
        const orders = await Order.find({ user: user._id });
        const totalSpent = orders.reduce((sum, order) => sum + order.total, 0);
        
        return {
          ...user.toObject(),
          orderCount: orders.length,
          totalSpent
        };
      })
    );
    
    res.json(usersWithStats);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get user statistics (admin only)
router.get('/stats', adminAuth, async (req, res) => {
  try {
    const totalUsers = await User.countDocuments({ role: 'user' });
    const newUsersToday = await User.countDocuments({
      role: 'user',
      createdAt: { $gte: new Date().setHours(0, 0, 0, 0) }
    });
    
    const orders = await Order.find();
    const totalRevenue = orders.reduce((sum, order) => sum + order.total, 0);
    const averageOrderValue = totalRevenue / (orders.length || 1);

    res.json({
      totalUsers,
      newUsersToday,
      totalRevenue,
      averageOrderValue,
      totalOrders: orders.length
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

export default router;